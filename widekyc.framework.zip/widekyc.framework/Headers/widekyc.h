//
//  widekyc.h
//  widekyc
//
//  Created by H, Alfatkhu on 24/03/22.
//

#import <Foundation/Foundation.h>

//! Project version number for widekyc.
FOUNDATION_EXPORT double widekycVersionNumber;

//! Project version string for widekyc.
FOUNDATION_EXPORT const unsigned char widekycVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <widekyc/PublicHeader.h>


